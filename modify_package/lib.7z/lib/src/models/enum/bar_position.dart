/// Position the inbuilt Toolbar or use your custom toolbar
enum BarPosition { TOP, BOTTOM, CUSTOM }
