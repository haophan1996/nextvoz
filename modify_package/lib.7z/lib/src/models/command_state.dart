class CommandState {
  bool executable = false;
  var value = "";

  CommandState(this.executable, this.value);
}
