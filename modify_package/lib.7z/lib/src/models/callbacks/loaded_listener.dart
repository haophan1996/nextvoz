class LoadedListener {
  editorLoaded() {}
}
